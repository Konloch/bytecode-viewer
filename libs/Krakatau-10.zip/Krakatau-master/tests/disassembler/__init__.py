# Mapping from test name -> tuple of argument lists.
registry = {
    'AnnotationsTest': ([],),
    'LineNumbersTest': ([],),
    'MethodParametersTest': ([],),
    'Primes': (['2'], ['3'], ['55555']),
    'SelfInner': ([],),
}
